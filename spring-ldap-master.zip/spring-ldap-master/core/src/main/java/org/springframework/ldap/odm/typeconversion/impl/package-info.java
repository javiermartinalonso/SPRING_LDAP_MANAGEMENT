/**
 * Provides an implementation of the {@link org.springframework.ldap.odm.typeconversion.ConverterManager} interface.
 * 
 * @author Paul Harvey &lt;paul.at.pauls-place.me.uk&gt;
 */

package org.springframework.ldap.odm.typeconversion.impl;

