package org.springframework.ldap.odm.typeconversion.impl;

/**
 * @author Mattias Hellborg Arthursson
 */
public class StringConverter {
}
