/**
 * Provides some basic implementations of the {@link org.springframework.ldap.odm.typeconversion.impl.Converter} interface.
 * 
 * @author Paul Harvey &lt;paul.at.pauls-place.me.uk&gt;
 */

package org.springframework.ldap.odm.typeconversion.impl.converters;