package org.springframework.ldap.config;

/**
 * @author Mattias Hellborg Arthursson
 */
public class DummyEntity {
}
