The page containing snapshot zip builds is actually a PHP page which takes the
XML listing from S3, and transforms it into links using a XSLT. The required
files should be placed on the following location:

http://static.springframework.org/spring-ldap/downloads/1.3-snapshot-download.php

